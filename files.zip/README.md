# Chez Michel — One-Page Website

Statische Website für die Bar *Chez Michel · Zufluchtsort* (Marktgasse 7, Tübingen).
Stil: Comic-Noir in Gelb/Schwarz, angelehnt an die Comic-Getränkekarten der Bar.

## Struktur
```
index.html
assets/
  fonts/AlfaSlabOne-Regular.ttf   (selbst gehostet)
  img/                            (Hero, Pin-up, Ladies Night, Getränkekarten)
```
Alles ist statisch, kein Build-Schritt nötig.

> **Hinweis:** `index.html` ist eigenständig — alle Bilder und die Schrift sind direkt eingebettet. Für einen funktionierenden Upload genügt **diese eine Datei**. Der Ordner `assets/` liegt nur bei, falls du Bilder/Schrift später separat bearbeiten willst.


## Auf GitHub Pages veröffentlichen
1. Neues Repository anlegen, z. B. `chez-michel`.
2. Den kompletten Inhalt dieses Ordners (inkl. `index.html` und `assets/`) ins Repo pushen:
   ```bash
   git init
   git add .
   git commit -m "Chez Michel Website"
   git branch -M main
   git remote add origin https://github.com/<NUTZER>/chez-michel.git
   git push -u origin main
   ```
3. Im Repo: **Settings → Pages → Build and deployment**
   - Source: *Deploy from a branch*
   - Branch: `main` / `/ (root)` → **Save**
4. Nach ein paar Minuten ist die Seite unter
   `https://<NUTZER>.github.io/chez-michel/` erreichbar.

## Anpassen
- **Öffnungszeiten**: im Abschnitt „Finden" (`<ul class="hours">`) — die Zeiten stammen aus
  öffentlichen Verzeichnissen und sollten vor Veröffentlichung bestätigt werden.
- **Farben/Schrift**: alle Design-Tokens stehen oben in `:root { ... }`.
- **Links**: Instagram, Tripadvisor, Telefon und Google-Maps-Route sind im Footer/Nav hinterlegt.
